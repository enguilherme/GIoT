<?php
/**
 * Before single-product summary - open.
 *
 * @author     ThemeFusion
 * @copyright  (c) Copyright by ThemeFusion
 * @link       https://theme-fusion.com
 * @package    Avada
 * @subpackage Core
 * @since      5.1.0
 */

?>
<div class="<?php echo esc_attr( apply_filters( 'avada_single_product_images_wrapper_classes', 'avada-single-product-gallery-wrapper' ) ); ?>">
