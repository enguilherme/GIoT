var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var comandosSchema = new Schema({
  title: String,
  subtitle: String,
  topic: String,
  payload: String,
  system: String,
  ativo: Boolean
});

var comandos = mongoose.model("comandos", comandosSchema);
module.exports = comandos;