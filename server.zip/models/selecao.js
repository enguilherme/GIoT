var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var selecaoSchema = new Schema({
  title: String,
  subtitle: String,
  topic: String,
  payload: String,
  system: String,
  ativo: Boolean
});

var selecao = mongoose.model("selecoes", selecaoSchema);
module.exports = selecao;