const express = require('express')
const bodyParser = require('body-parser')
const cors = require('cors')
const morgan = require('morgan')
var mongoose = require('mongoose');

// Express configuration
const app = express()
app.use(morgan('combined'))
app.use(bodyParser.json())
app.use(cors())
app.listen(process.env.PORT || 8081)

// Mongoose configuration
mongoose.connect('mongodb://localhost:27017/homedb');
var db = mongoose.connection;
db.on("error", console.error.bind(console, "connection error"));
db.once("open", function(callback){
  console.log("Connection Succeeded");
});

var Energy = require("../models/energy");

// Test handler 
// Fetch all posts
app.get('/instant/:system', (req, res) => {
  Energy.find({device: req.params.system}).sort({'time': -1}).limit(1).lean().exec(
    function (e, data) {
         res.json(data)
  })
})

app.get('/energy/:system/:scale/:from/:to', (req, res) => {
  switch(req.params.scale) {
    case 'hour':
        Energy.aggregate([
            { $group: {
                _id: {
                  system: "$device",
                  date: { $dateToString: { format: "%Y-%m-%d %H", date: "$time" }}
                },
                generation_max: { $max: "$geracao.energia" },
                generation_min: { $min: "$geracao.energia" },
                consumption_max: { $max: "$consumo.energia" },
                consumption_min: { $min: "$consumo.energia" }
              }
            },
            { $project: {
                _id: 0,
                system: "$_id.system",
                date: "$_id.date",
                geracao: { $subtract: ["$generation_max","$generation_min"]},
                consumo: { $subtract: ["$consumption_max","$consumption_min"]}
              }
            },
            { $match: {
                system: req.params.system,
                date: { $gte: req.params.from, $lte: req.params.to}
              }
            },
            { $sort: {
                date: 1
              } 
            }], function (err, result) {
          if (err) {
            next(err)
          } else {
            res.json(result)
          }
        })
        break
    case 'day':
        Energy.aggregate([
          { $group: {
              _id: {
                system: "$device",
                date: { $dateToString: { format: "%Y-%m-%d", date: "$time" }}
              },
              generation_max: { $max: "$geracao.energia" },
              generation_min: { $min: "$geracao.energia" },
              consumption_max: { $max: "$consumo.energia" },
              consumption_min: { $min: "$consumo.energia" }
            }
          },
          { $project: {
              _id: 0,
              system: "$_id.system",
              date: "$_id.date",
              geracao: { $subtract: ["$generation_max","$generation_min"]},
              consumo: { $subtract: ["$consumption_max","$consumption_min"]}
            }
          },
          { $match: {
              system: req.params.system,
              date: { $gte: req.params.from, $lte: req.params.to}
            }
          },
          { $sort: {
              date: 1
            } 
          }], function (err, result) {
        if (err) {
          next(err)
        } else {
          res.json(result)
        }
        })
        break
    case 'month':
        Energy.aggregate([
            { $group: {
                _id: {
                  system: "$device",
                  date: { $dateToString: { format: "%Y-%m", date: "$time" }}
                },
                generation_max: { $max: "$geracao.energia" },
                generation_min: { $min: "$geracao.energia" },
                consumption_max: { $max: "$consumo.energia" },
                consumption_min: { $min: "$consumo.energia" }
              }
            },
            { $project: {
                _id: 0,
                system: "$_id.system",
                date: "$_id.date",
                geracao: { $subtract: ["$generation_max","$generation_min"]},
                consumo: { $subtract: ["$consumption_max","$consumption_min"]}
              }
            },
            { $match: {
                system: req.params.system,
                date: { $gte: req.params.from, $lte: req.params.to}
              }
            },
            { $sort: {
                date: 1
              } 
            }], function (err, result) {
          if (err) {
            next(err)
          } else {
            res.json(result)
          }
        })
        break
    case 'year':
        Energy.aggregate([
          { $group: {
              _id: {
                system: "$device",
                date: { $dateToString: { format: "%Y", date: "$time" }}
              },
              generation_max: { $max: "$geracao.energia" },
              generation_min: { $min: "$geracao.energia" },
              consumption_max: { $max: "$consumo.energia" },
              consumption_min: { $min: "$consumo.energia" }
            }
          },
          { $project: {
              _id: 0,
              system: "$_id.system",
              date: "$_id.date",
              geracao: { $subtract: ["$generation_max","$generation_min"]},
              consumo: { $subtract: ["$consumption_max","$consumption_min"]}
            }
          },
          { $match: {
              system: req.params.system,
              date: { $gte: req.params.from, $lte: req.params.to}
            }
          },
          { $sort: {
              date: 1
            } 
          }], function (err, result) {
        if (err) {
          next(err)
        } else {
          res.json(result)
        }
        })
        break
    default:
        Energy.aggregate([
          { $group: {
              _id: {
                system: "$device",
                date: { $dateToString: { format: "%Y", date: "$time" }}
              },
              generation_max: { $max: "$geracao.energia" },
              generation_min: { $min: "$geracao.energia" },
              consumption_max: { $max: "$consumo.energia" },
              consumption_min: { $min: "$consumo.energia" }
            }
          },
          { $project: {
              _id: 0,
              system: "$_id.system",
              date: "$_id.date",
              geracao: { $subtract: ["$generation_max","$generation_min"]},
              consumo: { $subtract: ["$consumption_max","$consumption_min"]}
            }
          },
          { $match: {
              system: req.params.system,
              date: { $gte: req.params.from, $lte: req.params.to}
            }
          },
          { $sort: {
              date: 1
            } 
          }], function (err, result) {
        if (err) {
          next(err)
        } else {
          res.json(result)
        }
        })
  }
})
