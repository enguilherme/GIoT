var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var systemsSchema = new Schema({
  date: Date,
  system: String,
  address: String,
  city: String,
  zip: String,
  lat: String,
  lon: String,
  owner: String,
  cpf: Number,
  active: Boolean
});

var systems = mongoose.model("systems", systemsSchema);
module.exports = systems;