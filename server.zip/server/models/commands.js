var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var commandsSchema = new Schema({
  icon: String,
  icon_class: String,
  title: String,
  subtitle: String,
  topic: String,
  payload: String,
  system: String,
  active: Boolean
});

var commands = mongoose.model("commands", commandsSchema);
module.exports = commands;