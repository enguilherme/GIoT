var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var commandsSchema = new Schema({
  title: String,
  subtitle: String,
  topic: String,
  payload: String,
  system: String,
  active: Boolean
});

var commands = mongoose.model("commands", commandsSchema);
module.exports = commands;