var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var energySchema = new Schema({
  time: Date,
  device: String,
  geracao: { tensao: Number, corrente: Number, potencia: Number, energia: Number },
  consumo: { tensao: Number, corrente: Number, potencia: Number, energia: Number }
});

var energy = mongoose.model("energy", energySchema);
module.exports = energy;