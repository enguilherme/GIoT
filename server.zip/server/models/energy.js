var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var EnergySchema = new Schema({
  time: Date,
  device: String,
  geracao: { tensao: Number, corrente: Number, potencia: Number, energia: Number },
  consumo: { tensao: Number, corrente: Number, potencia: Number, energia: Number }
});

var Energy = mongoose.model("Energy", EnergySchema);
module.exports = Energy;