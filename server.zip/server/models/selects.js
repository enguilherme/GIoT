var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var selectsSchema = new Schema({
  title: String,
  subtitle: String,
  topic: String,
  payload: String,
  system: String,
  active: Boolean
});

var selects = mongoose.model("selects", selectsSchema);
module.exports = selects;