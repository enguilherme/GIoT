<script>
import { Bar } from 'vue-chartjs'
import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips'
import axios from 'axios'

export default {
  extends: Bar,
  props: ['height'],
  mounted () {
    axios.get('http://giot.com.br:1880/ano')
          .then(response => {
            let results = response.data
            let ano = results.map(a => a.Ano)
            let geracao = results.map(a => a.Geracao)
            let consumo = results.map(a => - a.Consumo)
            let diferenca = results.map(a => a.Geracao - a.Consumo)
            this.byano = ano
            this.bygeracao = geracao
            this.byconsumo = consumo
            this.bydiferenca = diferenca
    const datasets4 = [
      {
        label: 'Geração',
        backgroundColor: 'rgba(255,255,255,.3)',
        borderColor: 'transparent',
        data: this.bygeracao
      },
      {
        label: 'Consumo',
        backgroundColor: 'rgba(255,255,255,.3)',
        borderColor: 'transparent',
        data: this.byconsumo
      },
      {
        label: 'Diferença',
        backgroundColor: 'rgba(255,255,255,.3)',
        borderColor: 'transparent',
        data: this.bydiferenca
      }
    ]
    this.renderChart(
      {
        labels: this.byano,
        datasets: datasets4
      },
      {
        tooltips: {
          enabled: false,
          custom: CustomTooltips
        },
        maintainAspectRatio: false,
        legend: {
          display: false
        },
        scales: {
          xAxes: [{
            display: false,
            categoryPercentage: 1,
            barPercentage: 0.5
          }],
          yAxes: [{
            display: false
          }]
        }
      }
    )
  })
  }
}
</script>
