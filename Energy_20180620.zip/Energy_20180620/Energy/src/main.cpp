#include <FS.h>                   //this needs to be first, or it all crashes and burns...
#include <NTPClient.h>
#if defined(ESP8266)
  #include <ESP8266WiFi.h>          //https://github.com/esp8266/Arduino
#else
  #include <WiFi.h>          //https://github.com/esp8266/Arduino
  #include <SPIFFS.h>
#endif
//#include <WiFiUdp.h>
//needed for library
#include <DNSServer.h>
#if defined(ESP8266)
  #include <ESP8266WebServer.h>
#else
  #include <WebServer.h>
#endif
#include <WiFiManager.h>          //https://github.com/tzapu/WiFiManager

#include <ArduinoJson.h>          //https://github.com/bblanchon/ArduinoJson

#include <PubSubClient.h>
#include <HardwareSerial.h>
#include <PZEM004T.h>

#define MAX_BUFFER_SIZE 400

//define your default values here, if there are different values in settings.json, they are overwritten.
//length should be max size + 1
char mqtt_server[40] = "giot.com.br";
char mqtt_port[6] = "1883";
char mqtt_user[11] = "home";
char mqtt_pass[11] = "";
char mqtt_topic[40] = "ESP164/";
char mqtt_device[11] = "home";
char mqtt_measure1[11] = "geracao";
char mqtt_measure2[11] = "consumo";
char mqtt_clientid[11] = "ESP164";
char mqtt_period[3] = "60";

//default custom static IP
char static_ip[16] = "192.168.100.56";
char static_gw[16] = "192.168.100.1";
char static_dns[16] = "192.168.100.1";
char static_sn[16] = "255.255.255.0";

HardwareSerial Serial1(1);     // Use hwserial UART1 at pins IO-09 (RX1) and IO-10 (TX1)
HardwareSerial Serial2(2);     // Use hwserial UART2 at pins IO-16 (RX2) and IO-17 (TX2)
PZEM004T pzem1(&Serial1);
PZEM004T pzem2(&Serial2);
IPAddress ip1(192,168,1,1);
IPAddress ip2(192,168,1,2);

WiFiClient wifiClient;
PubSubClient client(wifiClient);

WiFiUDP ntpUDP;

NTPClient timeClient(ntpUDP, "gps.ntp.br", -10800, 60000);

//flag for saving data
bool shouldSaveConfig = false;

//callback notifying us of the need to save config
void saveConfigCallback () {
  Serial.println("Should save config");
  shouldSaveConfig = true;
}

void publicaenergia() {
  timeClient.update();
  client.setServer(mqtt_server, atoi(mqtt_port));
  String clientId = mqtt_clientid;
  clientId += "-";
  clientId += String(random(0xffff), HEX);
  if (client.connect(clientId.c_str(),mqtt_user,mqtt_pass)) {
    DynamicJsonBuffer JSONbuffer;
      JsonObject& JSONencoder = JSONbuffer.createObject();
      JSONencoder["time"] = timeClient.getEpochTime();
      JSONencoder["device"] = mqtt_device;
      JsonObject& medicoes_1 = JSONencoder.createNestedObject(mqtt_measure1);
  float v1 = pzem1.voltage(ip1);
  if (v1 < 0.0) v1 = 0.0; medicoes_1.set("tensao", v1);
  float i1 = pzem1.current(ip1);
   if(i1 >= 0.0){ medicoes_1.set("corrente", i1); }
  float p1 = pzem1.power(ip1);
   if(p1 >= 0.0){ medicoes_1.set("potencia", p1); }
  float e1 = pzem1.energy(ip1);
   if(e1 >= 0.0){ medicoes_1.set("energia", e1); }

      JsonObject& medicoes_2 = JSONencoder.createNestedObject(mqtt_measure2);
  float v2 = pzem2.voltage(ip2);
  if (v2 < 0.0) v2 = 0.0; medicoes_2.set("tensao", v2);
  float i2 = pzem2.current(ip2);
   if(i2 >= 0.0){ medicoes_2.set("corrente", i2); }
  float p2 = pzem2.power(ip2);
   if(p2 >= 0.0){ medicoes_2.set("potencia", p2); }
  float e2 = pzem2.energy(ip2);
   if(e2 >= 0.0){ medicoes_2.set("energia", e2); }

  char JSONmessageBuffer[MAX_BUFFER_SIZE];

  JSONencoder.printTo(JSONmessageBuffer, sizeof(JSONmessageBuffer));
  client.publish(mqtt_topic, JSONmessageBuffer);
  JSONencoder.printTo(Serial);
 }
}

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  Serial1.begin(9600, SERIAL_8N1, 22, 23, false);    //Serial 1 Baud rate, parity mode, RX, TX
  Serial2.begin(9600, SERIAL_8N1, 16, 17, false);  //Serial 2 Baud rate, parity mode, RX, TX

  //clean FS, for testing
  //SPIFFS.format();

  //read configuration from FS json
  Serial.println("mounting FS...");

  if (SPIFFS.begin()) {
    Serial.println("mounted file system");
    if (SPIFFS.exists("/settings.json")) {
      //file exists, reading and loading
      Serial.println("reading config file");
      File configFile = SPIFFS.open("/settings.json", "r");
      if (configFile) {
        Serial.println("opened config file");
        size_t size = configFile.size();
        // Allocate a buffer to store contents of the file.
        std::unique_ptr<char[]> buf(new char[size]);

        configFile.readBytes(buf.get(), size);
        DynamicJsonBuffer jsonBuffer;
        JsonObject& json = jsonBuffer.parseObject(buf.get());
        json.printTo(Serial);
        if (json.success()) {
          Serial.println("\nparsed json");

          strcpy(mqtt_server, json["mqtt_server"]);
          strcpy(mqtt_port, json["mqtt_port"]);
          strcpy(mqtt_user, json["mqtt_user"]);
          strcpy(mqtt_pass, json["mqtt_pass"]);
          strcpy(mqtt_topic, json["mqtt_topic"]);
          strcpy(mqtt_device, json["mqtt_device"]);
          strcpy(mqtt_measure1, json["mqtt_measure1"]);
          strcpy(mqtt_measure2, json["mqtt_measure2"]);
          strcpy(mqtt_clientid, json["mqtt_clientid"]);
          strcpy(mqtt_period, json["mqtt_period"]);

          if(json["ip"]) {
            Serial.println("setting custom ip from config");
            //static_ip = json["ip"];
            strcpy(static_ip, json["ip"]);
            strcpy(static_gw, json["gateway"]);
            strcpy(static_sn, json["subnet"]);
            strcpy(static_dns, json["dns"]);
            //strcat(static_ip, json["ip"]);
            //static_gw = json["gateway"];
            //static_sn = json["subnet"];
            Serial.println(static_ip);
            //Serial.println("converting ip");
            //IPAddress ip = ipFromCharArray(static_ip);
            //Serial.println(ip);
          } else {
            Serial.println("no custom ip in config");
          }
        } else {
          Serial.println("failed to load json config");
        }
      }
    }
  } else {
    Serial.println("failed to mount FS");
  }
  //end read

  // The extra parameters to be configured (can be either global or just in the setup)
  // After connecting, parameter.getValue() will get you the configured value
  // id/name placeholder/prompt default length
  WiFiManagerParameter custom_mqtt_server("server", "MQTT server", mqtt_server, 40);
  WiFiManagerParameter custom_mqtt_port("port", "MQTT port", mqtt_port, 6);
  WiFiManagerParameter custom_mqtt_user("user", "MQTT user", mqtt_user, 11);
  WiFiManagerParameter custom_mqtt_pass("pass", "MQTT password", mqtt_pass, 11);
  WiFiManagerParameter custom_mqtt_topic("topic", "MQTT topic", mqtt_topic, 40);
  WiFiManagerParameter custom_mqtt_device("device", "MQTT device", mqtt_device, 11);
  WiFiManagerParameter custom_mqtt_measure1("measure1", "MQTT device measure 1", mqtt_measure1, 11);
  WiFiManagerParameter custom_mqtt_measure2("measure2", "MQTT device measure 2", mqtt_measure2, 11);
  WiFiManagerParameter custom_mqtt_clientid("clientid", "MQTT client id", mqtt_clientid, 11);
  WiFiManagerParameter custom_mqtt_period("period", "MQTT period", mqtt_period, 3);

  //WiFiManager
  //Local intialization. Once its business is done, there is no need to keep it around
  WiFiManager wifiManager;

  //set config save notify callback
  wifiManager.setSaveConfigCallback(saveConfigCallback);

  //set static ip
  IPAddress _ip,_gw,_sn,_dns;
  _ip.fromString(static_ip);
  _gw.fromString(static_gw);
  _sn.fromString(static_sn);
  _dns.fromString(static_dns);

  wifiManager.setSTAStaticIPConfig(_ip, _gw, _sn, _dns);

  //add all your parameters here
  wifiManager.addParameter(&custom_mqtt_server);
  wifiManager.addParameter(&custom_mqtt_port);
  wifiManager.addParameter(&custom_mqtt_user);
  wifiManager.addParameter(&custom_mqtt_pass);
  wifiManager.addParameter(&custom_mqtt_topic);
  wifiManager.addParameter(&custom_mqtt_device);
  wifiManager.addParameter(&custom_mqtt_measure1);
  wifiManager.addParameter(&custom_mqtt_measure2);
  wifiManager.addParameter(&custom_mqtt_clientid);
  wifiManager.addParameter(&custom_mqtt_period);

  //reset settings - for testing
  //wifiManager.resetSettings();

  //set minimu quality of signal so it ignores AP's under that quality
  //defaults to 8%
  wifiManager.setMinimumSignalQuality();

  //sets timeout until configuration portal gets turned off
  //useful to make it all retry or go to sleep
  //in seconds
  //wifiManager.setConfigPortalTimeout(180);
  wifiManager.setConnectTimeout(5);
  wifiManager.setSaveConnectTimeout(5);
  //fetches ssid and pass and tries to connect
  //if it does not connect it starts an access point with the specified name
  //here  "AutoConnectAP"
  //and goes into a blocking loop awaiting configuration
  if (!wifiManager.autoConnect("GIoT")) {
    Serial.println("failed to connect and hit timeout");
    delay(3000);
    //reset and try again, or maybe put it to deep sleep
    ESP.restart();
    delay(5000);
  }

  //if you get here you have connected to the WiFi

  //read updated parameters
  strcpy(mqtt_server, custom_mqtt_server.getValue());
  strcpy(mqtt_port, custom_mqtt_port.getValue());
  strcpy(mqtt_user, custom_mqtt_user.getValue());
  strcpy(mqtt_pass, custom_mqtt_pass.getValue());
  strcpy(mqtt_topic, custom_mqtt_topic.getValue());
  strcpy(mqtt_device, custom_mqtt_device.getValue());
  strcpy(mqtt_measure1, custom_mqtt_measure1.getValue());
  strcpy(mqtt_measure2, custom_mqtt_measure2.getValue());
  strcpy(mqtt_clientid, custom_mqtt_clientid.getValue());
  strcpy(mqtt_period, custom_mqtt_period.getValue());

  //save the custom parameters to FS
  if (shouldSaveConfig) {
    Serial.println("saving config");
    DynamicJsonBuffer jsonBuffer;
    JsonObject& json = jsonBuffer.createObject();
    json["mqtt_server"] = mqtt_server;
    json["mqtt_port"] = mqtt_port;
    json["mqtt_user"] = mqtt_user;
    json["mqtt_pass"] = mqtt_pass;
    json["mqtt_topic"] = mqtt_topic;
    json["mqtt_device"] = mqtt_device;
    json["mqtt_measure1"] = mqtt_measure1;
    json["mqtt_measure2"] = mqtt_measure2;
    json["mqtt_clientid"] = mqtt_clientid;
    json["mqtt_period"] = mqtt_period;

    json["ip"] = WiFi.localIP().toString();
    json["gateway"] = WiFi.gatewayIP().toString();
    json["dns"] = WiFi.dnsIP().toString();
    json["subnet"] = WiFi.subnetMask().toString();

    File configFile = SPIFFS.open("/settings.json", "w");
    if (!configFile) {
      Serial.println("failed to open config file for writing");
    }

    json.prettyPrintTo(Serial);
    json.printTo(configFile);
    configFile.close();
    //end save
  }

  Serial.print("Connecting to PZEM ...");
  while (true) {
   Serial.print(".");
   if(pzem1.setAddress(ip1) && pzem2.setAddress(ip2))
     break;
   delay(1000);
  }
}

void loop() {
  // put your main code here, to run repeatedly:

    publicaenergia();
    //client.loop();
    delay(atoi(mqtt_period)*1000);
}
